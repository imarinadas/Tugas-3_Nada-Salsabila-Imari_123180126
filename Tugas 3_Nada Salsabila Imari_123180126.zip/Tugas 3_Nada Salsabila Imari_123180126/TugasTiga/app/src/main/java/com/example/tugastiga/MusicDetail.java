package com.example.tugastiga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.xml.sax.ErrorHandler;

import java.util.logging.ErrorManager;

public class MusicDetail extends AppCompatActivity {
    private TextView detailTitle, detailArtist, detailYear;
    private ImageView detailCover;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();

        final int cover = intent.getExtras().getInt("cover");
        final String title = intent.getExtras().getString("title");
        final String artist = intent.getExtras().getString("artist");
        final String year = intent.getExtras().getString("year");

        detailCover = findViewById(R.id.cover);
        detailTitle = findViewById(R.id.title);
        detailArtist = findViewById(R.id.artist);
        detailYear = findViewById(R.id.year);

        if(getIntent().getExtras() != null) {
            detailCover.setImageResource(cover);
            detailTitle.setText("Title : " + title);
            detailArtist.setText("Artist : " + artist);
            detailYear.setText("Year : " + year);
        }
    }
}