package com.example.tugastiga;

import java.util.ArrayList;

public class MusicData {
    private static String[] title = new String[]{"Every letter I sent you.", "LEGEND", "Our Love is Great",
        "The Hottest: N.Flying", "Chat-Shire"};
    private static int[] thumbnail = new int[]{R.drawable.img1, R.drawable.img2, R.drawable.img3,
        R. drawable.img4, R.drawable.img5};
    private static String[] name = new String[]{"Yerin Baek", "Jannabi", "Yerin Baek", "N.Flying",
        "IU"};
    private static String[] released = new String[]{"2019", "2019", "2019", "2018", "2015"};

    public static ArrayList<MusicModel> getListData(){
        MusicModel musicModel = null;
        ArrayList<MusicModel> list = new ArrayList<>();
        for(int i = 0; i <title.length; i++){
            musicModel = new MusicModel();
            musicModel.setCoverMusic(thumbnail[i]);
            musicModel.setTitleMusic(title[i]);
            musicModel.setArtist(name[i]);
            musicModel.setYear(released[i]);
            list.add(musicModel);
        }
        return list;
    }
}
