package com.example.tugastiga;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.ViewHolder> {
    @NonNull
    @Override
    public MusicAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemRow = LayoutInflater.from(viewGroup.getContext()).
                inflate(R.layout.item_music, viewGroup, false);
        return new ViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull MusicAdapter.ViewHolder viewHolder, int i) {
        Glide.with(context).load(getMusicModels().get(i).getCoverMusic()).into
                (viewHolder.ivCover);
        viewHolder.tvTitle.setText(getMusicModels().get(i).getTitleMusic());
        viewHolder.btnShare.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, "Listen to : "
                + getMusicModels().get(i).getTitleMusic() + "\nPerformed by : "
                + getMusicModels().get(i).getArtist() + "\nReleased on : "
                + getMusicModels().get(i).getYear());
                intent.setType("text/plain");
                context.startActivity(Intent.createChooser(intent, "Send to"));
            }
        });
        viewHolder.btnDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MusicDetail.class);
                intent.putExtra("cover", getMusicModels().get(i).getCoverMusic());
                intent.putExtra("title", getMusicModels().get(i).getTitleMusic());
                intent.putExtra("artist", getMusicModels().get(i).getArtist());
                intent.putExtra("year", getMusicModels().get(i).getYear());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return getMusicModels().size();
    }

    public class ViewHolder extends  RecyclerView.ViewHolder{
        private ImageView ivCover;
        private TextView tvTitle;
        private Button btnShare;
        private Button btnDetail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.cover);
            tvTitle = itemView.findViewById(R.id.title);
            btnShare = itemView.findViewById(R.id.share);
            btnDetail = itemView.findViewById(R.id.detail);
        }
    }

    private Context context;
    private ArrayList<MusicModel> musicModels;

    public ArrayList<MusicModel> getMusicModels() {
        return musicModels;
    }

    public void setMusicModels(ArrayList<MusicModel> musicModels) {
        this.musicModels = musicModels;
    }

    public MusicAdapter(Context context) {
        this.context = context;
    }
}
