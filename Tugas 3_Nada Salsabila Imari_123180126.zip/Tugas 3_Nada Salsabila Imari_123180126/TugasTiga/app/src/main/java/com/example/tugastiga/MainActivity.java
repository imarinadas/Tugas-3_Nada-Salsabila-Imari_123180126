package com.example.tugastiga;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvMusic;
    private ArrayList<MusicModel> listMusic = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvMusic = findViewById(R.id.rv_musicList);
        rvMusic.setHasFixedSize(true);
        listMusic.addAll(MusicData.getListData());

        showRecyclerList();
    }

    private void showRecyclerList(){
        rvMusic.setLayoutManager(new LinearLayoutManager(this));
        MusicAdapter musicAdapter = new MusicAdapter(this);
        musicAdapter.setMusicModels(listMusic);
        rvMusic.setAdapter(musicAdapter);
    }
}