package com.example.tugastiga;

public class MusicModel {
    private String titleMusic, artist, year;
    private int coverMusic;

    public String getTitleMusic() {
        return titleMusic;
    }

    public void setTitleMusic(String titleMusic) {
        this.titleMusic = titleMusic;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getCoverMusic() {
        return coverMusic;
    }

    public void setCoverMusic(int coverMusic) {
        this.coverMusic = coverMusic;
    }
}
